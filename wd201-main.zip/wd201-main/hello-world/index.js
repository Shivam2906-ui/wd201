const hello =() =>{
    console.log("Hello World");

};
hello();